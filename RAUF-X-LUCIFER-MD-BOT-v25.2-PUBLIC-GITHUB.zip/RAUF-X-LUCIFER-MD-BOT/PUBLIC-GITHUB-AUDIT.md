# Public GitHub preparation audit

This archive was prepared for a public repository.

## Changes made
- Removed the hard-coded Telegram bot token and switched the sticker command to `TELEGRAM_STICKER_BOT_TOKEN` / `TELEGRAM_BOT_TOKEN` from the private environment.
- Removed hard-coded API credentials from integrations and moved them to blank environment variables in `.env.example`.
- Kept public API provider names and base endpoint URLs in the source.
- Removed hard-coded owner WhatsApp numbers, Telegram admin IDs, and live owner/premium seed entries.
- Removed hard-coded third-party scraper cookies.
- Kept only safe default data templates; runtime data is excluded by `.gitignore`.
- Updated GitHub upload instructions to use a Public repository.

## API endpoints
Public endpoint URLs and provider identifiers were intentionally retained. Where a provider requires a key, configure the corresponding variable in your private `.env` file. Examples include:
`OPENWEATHER_API_KEY`, `NEWS_API_KEY`, `GIPHY_API_KEY`, `OMDB_API_KEY`, `PIXABAY_API_KEY`, `IMGBB_API_KEY`, `SHIZO_API_KEY`, `PRINCETECH_API_KEY`, `GIFTED_API_KEY`, `RAGANORK_API_KEY`, and `TIKTOK_API_KEY`.

## Verification
- `npm run check`: 384/384 JavaScript files passed syntax checks.
- `npm test`: passed.
- `npm run test:security`: 94 passed, 0 failed.

## Important
The original uploaded archive contained credentials. Treat every credential from that original archive as exposed: revoke/rotate the Telegram bot token and any third-party API keys before using them again. Never upload your real `.env`, session folders, WhatsApp credentials, or admin secrets.
