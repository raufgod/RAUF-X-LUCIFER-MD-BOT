const card = require('../lib/cardStyle');
const fetch = require('node-fetch');

async function truthCommand(sock, chatId, message) {
    try {
        const shizokeys = process.env.SHIZO_API_KEY || '';
        const res = await fetch(`https://shizoapi.onrender.com/api/texts/truth?apikey=${shizokeys}`);
        
        if (!res.ok) {
            throw await res.text();
        }
        
        const json = await res.json();
        const truthMessage = json.result;

        // Send the truth message
        await sock.sendMessage(chatId, { text: card.panel({ icon: '🤔', title: 'Truth', body: truthMessage }) }, { quoted: message });
    } catch (error) {
        console.error('Error in truth command:', error);
        await sock.sendMessage(chatId, { text: card.problem('Failed to get truth. Please try again later!') }, { quoted: message });
    }
}

module.exports = { truthCommand };
