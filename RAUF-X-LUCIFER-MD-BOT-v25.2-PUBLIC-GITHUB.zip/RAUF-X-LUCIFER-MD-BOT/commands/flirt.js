const card = require('../lib/cardStyle');
const fetch = require('node-fetch');

async function flirtCommand(sock, chatId, message) {
    try {
        const shizokeys = process.env.SHIZO_API_KEY || '';
        const res = await fetch(`https://shizoapi.onrender.com/api/texts/flirt?apikey=${shizokeys}`);
        
        if (!res.ok) {
            throw await res.text();
        }
        
        const json = await res.json();
        const flirtMessage = json.result;

        // Send the flirt message
        await sock.sendMessage(chatId, { text: card.panel({ icon: '💘', title: 'Flirt', body: flirtMessage }) }, { quoted: message });
    } catch (error) {
        console.error('Error in flirt command:', error);
        await sock.sendMessage(chatId, { text: card.problem('Failed to get flirt message. Please try again later!') }, { quoted: message });
    }
}

module.exports = { flirtCommand }; 